# IPL_Match_Probability
this project will predict the winning percent of the batting team as well as bowling team on the basis of the venue and other factors
